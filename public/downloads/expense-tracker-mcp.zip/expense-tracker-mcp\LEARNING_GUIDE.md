# Learning Guide

## 1. Database first

`database.py` creates one `expenses` table and indexes the date and category columns. Each action opens a short-lived SQLite connection; `?` placeholders pass values safely to SQL. The server never lets an AI model query SQLite directly: the model asks an MCP client to call a deliberately limited tool, and the server validates and performs the operation.

## 2. Money conversion

`money.py` uses `Decimal`, so `"350.75"` becomes exactly `35075` paise. Floating-point values are avoided because common decimals cannot always be represented exactly in binary. `format_inr` converts integer paise back to display text such as `₹12,34,567.00`.

## 3. Adding an expense

For “Add ₹350 for lunch under food”, the client calls `add_expense`. In `server.py`, the function parses money, checks category, description, date, and payment method, then calls `ExpenseDatabase.add`. Its structured response includes both stored `amount_paise` and readable `amount`.

## 4. Reporting tools

`get_monthly_total` asks SQLite to run `SUM(amount_paise)`. `category_breakdown` uses `GROUP BY category`, so the AI never has to calculate totals. `list_expenses` supplies the individual records and filters.

## 5. Updates and deletes

`update_expense` requires at least one changed value and updates `updated_at`. `delete_expense` refuses unless `confirm=true`; this gives the human a clear final confirmation point. Expected input/business problems raise a user-facing tool error; unexpected failures still surface as server errors for diagnosis.

## 6. Resource

The read-only `expenses://current-month/summary` resource combines monthly aggregate data, categories, and the highest individual expense. Unlike a tool, a resource is information addressed by a URI and should not modify data.

## 7. Prompt

`analyze_monthly_spending` is reusable guidance, not a query. It tells the model to call the three reporting tools, avoid judgment and edits, and provide INR savings suggestions. A prompt can help an AI follow a workflow without silently touching the database.

## 8. MCP request flow

```text
User -> AI Model -> MCP Client -> tools/call -> Expense Tracker server
     -> validation -> SQLite INSERT -> MCP structured result -> AI response
```

FastMCP's `@mcp.tool()` reads Python type hints to build tool schemas for clients. `@mcp.resource()` and `@mcp.prompt()` similarly register information and reusable instructions. In current MCP SDK releases, FastMCP remains part of the official `mcp` package and `FastMCP.run(transport="stdio")` starts stdio; this project uses that current API rather than older standalone FastMCP packages.

## 9. Real AI terminal host

`terminal_app.py` is deliberately predictable: it parses a small command format itself and
then calls the MCP server. `ai_terminal_app.py` is the real AI flow. It asks the local MCP
server for its tool schemas, supplies those schemas to an OpenAI model as function tools,
and sends each model-selected function call to the local server over stdio. The tool result
goes back to the model, which writes the terminal reply.

This separation matters: the model selects an allowed action, but it never connects to
SQLite or executes arbitrary SQL. `delete_expense` still requires the human's explicit
confirmation before the host sends `confirm=true`.

## 10. Adding another tool

Write a small typed function in `create_server`, add `@mcp.tool()`, keep validation/database access in their existing modules, add tests with a temporary database, then update both guides.
