"""Validation for the fixed values accepted by this learning project."""

import re
from datetime import date

CATEGORIES = frozenset(
    {
        "food",
        "groceries",
        "travel",
        "bills",
        "shopping",
        "entertainment",
        "health",
        "education",
        "other",
    }
)
PAYMENT_METHODS = frozenset({"cash", "upi", "card", "bank_transfer", "other"})
MONTH_PATTERN = re.compile(r"^\d{4}-\d{2}$")


class ValidationError(ValueError):
    """Raised for expected, user-correctable tool inputs."""


def validate_category(category: str) -> str:
    if category not in CATEGORIES:
        raise ValidationError(
            f"Unsupported category. Choose one of: {', '.join(sorted(CATEGORIES))}."
        )
    return category


def validate_payment_method(payment_method: str) -> str:
    if payment_method not in PAYMENT_METHODS:
        raise ValidationError(
            f"Unsupported payment method. Choose one of: {', '.join(sorted(PAYMENT_METHODS))}."
        )
    return payment_method


def validate_description(description: str) -> str:
    if not isinstance(description, str) or not description.strip():
        raise ValidationError("Description must be non-empty text.")
    return description.strip()


def validate_date(value: str) -> str:
    try:
        return date.fromisoformat(value).isoformat()
    except (TypeError, ValueError) as exc:
        raise ValidationError("expense_date must use YYYY-MM-DD format.") from exc


def validate_month(value: str) -> str:
    if not isinstance(value, str) or not MONTH_PATTERN.fullmatch(value):
        raise ValidationError("month must use YYYY-MM format.")
    try:
        date.fromisoformat(f"{value}-01")
    except ValueError as exc:
        raise ValidationError("month must be a real calendar month in YYYY-MM format.") from exc
    return value
