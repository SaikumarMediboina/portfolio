"""Small typed records shared by the database and server."""

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class Expense:
    """One stored expense, with money represented as integer paise."""

    id: int
    amount_paise: int
    category: str
    description: str
    expense_date: str
    payment_method: str
    created_at: str
    updated_at: str | None

    def to_dict(self) -> dict[str, object]:
        """Return a JSON-compatible dictionary."""
        return asdict(self)
