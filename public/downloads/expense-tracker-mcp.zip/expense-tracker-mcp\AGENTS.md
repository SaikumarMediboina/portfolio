# Repository instructions

This project is a local stdio MCP server. Keep responsibilities separate: `server.py` exposes MCP features, `database.py` owns SQLite, and `money.py` parses/formats currency.

- Use Python 3.11+ type hints and concise docstrings.
- Never use `float` for money; use `Decimal` at the input boundary and integer paise in SQLite.
- Keep every SQL query parameterized. Tests must always use temporary databases.
- Never log or print to stdout: stdio is reserved for the MCP protocol. Use stderr logging only.
- Run `uv run ruff format .`, `uv run ruff check .`, and `uv run pytest` before handoff. Pytest uses `.pytest-tmp` rather than the user's system Temp directory.
- Update `README.md` and `LEARNING_GUIDE.md` whenever capabilities change.
