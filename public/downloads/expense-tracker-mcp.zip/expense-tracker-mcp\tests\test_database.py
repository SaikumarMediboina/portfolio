from expense_tracker_mcp.database import ExpenseDatabase


def test_add_list_and_filters(database: ExpenseDatabase) -> None:
    food = database.add(35000, "food", "Lunch", "2026-07-25", "upi")
    database.add(120000, "bills", "Electricity bill", "2026-07-25", "bank_transfer")
    database.add(65050, "travel", "Petrol", "2026-07-26", "card")
    assert food.id == 1
    assert len(database.list(month="2026-07")) == 3
    assert [item.category for item in database.list(category="food")] == ["food"]
    assert database.monthly_total("2026-07") == (3, 220050)
    assert database.breakdown("2026-07") == [
        ("bills", 1, 120000),
        ("travel", 1, 65050),
        ("food", 1, 35000),
    ]


def test_update_missing_empty_and_delete(database: ExpenseDatabase) -> None:
    expense = database.add(65050, "travel", "Petrol", "2026-07-26", "card")
    assert database.update(999, {"category": "food"}) is None
    assert database.update(expense.id, {}) is None
    updated = database.update(
        expense.id,
        {"amount_paise": 85000, "category": "groceries", "description": "Weekly groceries"},
    )
    assert updated is not None and updated.amount_paise == 85000 and updated.category == "groceries"
    assert (
        database.get(expense.id) is not None
    )  # confirm=false is enforced by the MCP tool, not storage.
    deleted = database.delete(expense.id)
    assert deleted is not None and database.get(expense.id) is None
