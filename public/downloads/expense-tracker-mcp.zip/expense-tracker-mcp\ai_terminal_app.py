"""AI-powered terminal host for the local Expense Tracker MCP server.

The terminal sends natural-language requests to the OpenAI Responses API.  The
model chooses from the MCP tools exposed by the local server; this file executes
the requested MCP call and returns its result to the model.
"""

import asyncio
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import date
from pathlib import Path
from typing import Any

from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

PROJECT_ROOT = Path(__file__).resolve().parent
OPENAI_RESPONSES_URL = "https://api.openai.com/v1/responses"
MODEL = os.environ.get("OPENAI_MODEL", "gpt-5")
sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def response_request(payload: dict[str, Any]) -> dict[str, Any]:
    """Send one Responses API request without putting the API key in source code."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY is not set. Set it in this PowerShell window, then run again."
        )
    request = urllib.request.Request(
        OPENAI_RESPONSES_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"OpenAI API request failed ({exc.code}): {detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not reach the OpenAI API: {exc.reason}") from exc


def as_openai_tools(mcp_tools: list[Any]) -> list[dict[str, Any]]:
    """Convert MCP's JSON schemas into OpenAI function-tool definitions."""
    tools: list[dict[str, Any]] = []
    for tool in mcp_tools:
        tools.append(
            {
                "type": "function",
                "name": tool.name,
                "description": tool.description or f"Call the {tool.name} MCP tool.",
                "parameters": tool.inputSchema,
                "strict": False,
            }
        )
    return tools


def tool_output(result: Any) -> str:
    """Turn an MCP result into the text passed back to the model."""
    texts = [content.text for content in result.content if hasattr(content, "text")]
    return "\n".join(texts) or json.dumps({"is_error": bool(result.isError)})


async def answer_with_tools(
    session: ClientSession,
    tools: list[dict[str, Any]],
    conversation: list[dict[str, Any]],
) -> str:
    """Let the model call local MCP tools until it returns a normal answer."""
    while True:
        response = await asyncio.to_thread(
            response_request,
            {
                "model": MODEL,
                "instructions": (
                    "You are a helpful personal expense-tracker assistant. Use the provided "
                    "tools for every request that needs expense data or changes expense data. "
                    "Never invent an expense, total, or result. Today is "
                    f"{date.today().isoformat()}. For deletion, call delete_expense with "
                    "confirm=false first. Only call it with confirm=true after the person "
                    "clearly confirms the specific deletion. Keep answers concise and show "
                    "amounts in Indian Rupees."
                ),
                "input": conversation,
                "tools": tools,
                "parallel_tool_calls": False,
                "store": False,
            },
        )
        output = response.get("output", [])
        conversation.extend(output)
        function_calls = [item for item in output if item.get("type") == "function_call"]
        if not function_calls:
            return response.get("output_text") or "I could not create a response."

        for call in function_calls:
            try:
                arguments = json.loads(call["arguments"])
            except json.JSONDecodeError:
                result_text = json.dumps({"error": "The model supplied invalid tool arguments."})
            else:
                result = await session.call_tool(call["name"], arguments=arguments)
                result_text = tool_output(result)
            conversation.append(
                {
                    "type": "function_call_output",
                    "call_id": call["call_id"],
                    "output": result_text,
                }
            )


def show_help() -> None:
    """Print examples that the model, rather than a command parser, understands."""
    print(
        """\nTry normal sentences:
  Add 350 for lunch under food
  I paid INR 1,200 for the electricity bill by bank transfer
  Show all expenses for this month
  Where did I spend the most in 2026-07?
  Change expense 2 to INR 1,350
  Delete expense 2
  Yes, delete expense 2

Type exit to close. The model decides which MCP tool to call.\n"""
    )


async def main() -> None:
    """Start the local server and keep a model-guided MCP conversation open."""
    environment = os.environ.copy()
    source_path = str(PROJECT_ROOT / "src")
    environment["PYTHONPATH"] = source_path + os.pathsep + environment.get("PYTHONPATH", "")
    parameters = StdioServerParameters(
        command=sys.executable,
        args=["-m", "expense_tracker_mcp.server"],
        env=environment,
        cwd=PROJECT_ROOT,
    )
    async with stdio_client(parameters) as (reader, writer):
        async with ClientSession(reader, writer) as session:
            await session.initialize()
            tools = as_openai_tools((await session.list_tools()).tools)
            conversation: list[dict[str, Any]] = []
            print("AI Expense Tracker is ready. Type help for examples; type exit to close.")
            while True:
                line = await asyncio.to_thread(input, "you> ")
                line = line.strip()
                if line.lower() in {"exit", "quit"}:
                    print("Goodbye.")
                    return
                if line.lower() == "help":
                    show_help()
                    continue
                if not line:
                    continue
                conversation.append({"role": "user", "content": line})
                try:
                    print(f"assistant> {await answer_with_tools(session, tools, conversation)}")
                except RuntimeError as exc:
                    print(f"Error: {exc}")


if __name__ == "__main__":
    asyncio.run(main())
