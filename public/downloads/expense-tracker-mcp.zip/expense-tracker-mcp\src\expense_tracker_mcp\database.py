"""SQLite storage with parameterized queries only."""

import builtins
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

from .models import Expense


def utc_now() -> str:
    """Return an ISO UTC timestamp suitable for SQLite text storage."""
    return datetime.now(UTC).replace(microsecond=0).isoformat()


class ExpenseDatabase:
    """A short-lived-connection SQLite repository for expenses."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connection() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS expenses (
                    id INTEGER PRIMARY KEY,
                    amount_paise INTEGER NOT NULL CHECK(amount_paise > 0),
                    category TEXT NOT NULL,
                    description TEXT NOT NULL,
                    expense_date TEXT NOT NULL,
                    payment_method TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_expenses_expense_date ON expenses(expense_date);
                CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category);
                """
            )

    def add(
        self,
        amount_paise: int,
        category: str,
        description: str,
        expense_date: str,
        payment_method: str,
    ) -> Expense:
        timestamp = utc_now()
        with self._connection() as connection:
            cursor = connection.execute(
                "INSERT INTO expenses "
                "(amount_paise, category, description, expense_date, payment_method, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (amount_paise, category, description, expense_date, payment_method, timestamp),
            )
            return self.get(int(cursor.lastrowid), connection=connection)  # type: ignore[return-value]

    def get(self, expense_id: int, connection: sqlite3.Connection | None = None) -> Expense | None:
        if connection is not None:
            row = connection.execute(
                "SELECT * FROM expenses WHERE id = ?", (expense_id,)
            ).fetchone()
            return self._expense(row) if row else None
        with self._connection() as owned_connection:
            return self.get(expense_id, connection=owned_connection)

    def list(
        self, month: str | None = None, category: str = "all", limit: int = 50
    ) -> list[Expense]:
        clauses: list[str] = []
        params: list[object] = []
        if month:
            clauses.append("expense_date >= ? AND expense_date < ?")
            year, month_number = map(int, month.split("-"))
            next_month = (
                f"{year + 1:04d}-01-01"
                if month_number == 12
                else f"{year:04d}-{month_number + 1:02d}-01"
            )
            params.extend([f"{month}-01", next_month])
        if category != "all":
            clauses.append("category = ?")
            params.append(category)
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        with self._connection() as connection:
            rows = connection.execute(
                f"SELECT * FROM expenses{where} ORDER BY expense_date DESC, id DESC LIMIT ?", params
            ).fetchall()
        return [self._expense(row) for row in rows]

    def monthly_total(self, month: str) -> tuple[int, int]:
        with self._connection() as connection:
            row = connection.execute(
                "SELECT COUNT(*) AS expense_count, "
                "COALESCE(SUM(amount_paise), 0) AS total_paise "
                "FROM expenses WHERE expense_date >= ? AND expense_date < ?",
                (f"{month}-01", self._next_month(month)),
            ).fetchone()
        return int(row["expense_count"]), int(row["total_paise"])

    def breakdown(self, month: str) -> builtins.list[tuple[str, int, int]]:
        with self._connection() as connection:
            rows = connection.execute(
                "SELECT category, COUNT(*) AS expense_count, SUM(amount_paise) AS total_paise "
                "FROM expenses WHERE expense_date >= ? AND expense_date < ? "
                "GROUP BY category ORDER BY total_paise DESC, category ASC",
                (f"{month}-01", self._next_month(month)),
            ).fetchall()
        return [
            (str(row["category"]), int(row["expense_count"]), int(row["total_paise"]))
            for row in rows
        ]

    def highest(self, month: str) -> Expense | None:
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM expenses WHERE expense_date >= ? AND expense_date < ? "
                "ORDER BY amount_paise DESC, id DESC LIMIT 1",
                (f"{month}-01", self._next_month(month)),
            ).fetchone()
        return self._expense(row) if row else None

    def update(self, expense_id: int, fields: dict[str, object]) -> Expense | None:
        if not fields:
            return None
        fields["updated_at"] = utc_now()
        assignments = ", ".join(f"{column} = ?" for column in fields)
        with self._connection() as connection:
            cursor = connection.execute(
                f"UPDATE expenses SET {assignments} WHERE id = ?", [*fields.values(), expense_id]
            )
            if cursor.rowcount == 0:
                return None
            return self.get(expense_id, connection=connection)

    def delete(self, expense_id: int) -> Expense | None:
        with self._connection() as connection:
            expense = self.get(expense_id, connection=connection)
            if expense is None:
                return None
            connection.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
            return expense

    @contextmanager
    def _connection(self):
        """Open, commit or roll back, and always close one SQLite connection."""
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _expense(row: sqlite3.Row) -> Expense:
        return Expense(**dict(row))

    @staticmethod
    def _next_month(month: str) -> str:
        year, month_number = map(int, month.split("-"))
        return (
            f"{year + 1:04d}-01-01"
            if month_number == 12
            else f"{year:04d}-{month_number + 1:02d}-01"
        )
