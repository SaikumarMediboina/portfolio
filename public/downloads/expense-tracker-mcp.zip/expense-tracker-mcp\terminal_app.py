"""Interactive terminal client for the local Expense Tracker MCP server."""

import asyncio
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

PROJECT_ROOT = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ADD_PATTERN = re.compile(
    r"^add\s+(?P<amount>\S+)\s+(?P<description>.+?)\s+under\s+"
    r"(?P<category>[a-z_]+)(?:\s+via\s+(?P<payment>[a-z_]+))?$",
    re.IGNORECASE,
)


def show_result(result: Any) -> None:
    """Print an MCP result's text contents as formatted JSON when possible."""
    for content in result.content:
        if hasattr(content, "text"):
            try:
                print(json.dumps(json.loads(content.text), ensure_ascii=False, indent=2))
            except json.JSONDecodeError:
                print(content.text)


async def run_command(session: ClientSession, line: str) -> None:
    """Translate the supported terminal commands into real MCP tool calls."""
    match = ADD_PATTERN.fullmatch(line)
    if match:
        values = match.groupdict()
        result = await session.call_tool(
            "add_expense",
            arguments={
                "amount_rupees": values["amount"],
                "category": values["category"].lower(),
                "description": values["description"],
                "payment_method": (values["payment"] or "upi").lower(),
            },
        )
        show_result(result)
        return

    parts = line.split()
    if len(parts) == 2 and parts[0] in {"total", "breakdown"}:
        tool_name = "get_monthly_total" if parts[0] == "total" else "category_breakdown"
        show_result(await session.call_tool(tool_name, arguments={"month": parts[1]}))
        return
    if parts and parts[0] == "list":
        arguments: dict[str, object] = {"limit": 50}
        if len(parts) == 2:
            arguments["month"] = parts[1]
        elif len(parts) > 2:
            print("Use: list  OR  list YYYY-MM")
            return
        show_result(await session.call_tool("list_expenses", arguments=arguments))
        return
    if len(parts) in {2, 3} and parts[0] == "delete" and parts[1].isdigit():
        confirmed = len(parts) == 3 and parts[2] == "confirm"
        show_result(
            await session.call_tool(
                "delete_expense", arguments={"expense_id": int(parts[1]), "confirm": confirmed}
            )
        )
        return
    print("I did not understand that command. Type help to see examples.")


def show_help() -> None:
    """Show the small, predictable command language supported by this client."""
    print(
        """\nCommands:
  add 350 Lunch under food
  add ₹1,200 Electricity bill under bills via bank_transfer
  list
  list 2026-07
  total 2026-07
  breakdown 2026-07
  delete 3
  delete 3 confirm
  exit
\nCategories: food, groceries, travel, bills, shopping, entertainment, health, education, other
Payment methods: cash, upi, card, bank_transfer, other\n"""
    )


async def main() -> None:
    """Keep a local MCP session open until the person exits the terminal client."""
    environment = os.environ.copy()
    source_path = str(PROJECT_ROOT / "src")
    environment["PYTHONPATH"] = source_path + os.pathsep + environment.get("PYTHONPATH", "")
    parameters = StdioServerParameters(
        command=sys.executable,
        args=["-m", "expense_tracker_mcp.server"],
        env=environment,
        cwd=PROJECT_ROOT,
    )
    async with stdio_client(parameters) as (reader, writer):
        async with ClientSession(reader, writer) as session:
            await session.initialize()
            print("Expense Tracker is ready. Type help for examples; type exit to close.")
            while True:
                line = await asyncio.to_thread(input, "expense> ")
                line = line.strip()
                if line.lower() in {"exit", "quit"}:
                    print("Goodbye.")
                    return
                if line.lower() == "help":
                    show_help()
                    continue
                if line:
                    await run_command(session, line)


if __name__ == "__main__":
    asyncio.run(main())
