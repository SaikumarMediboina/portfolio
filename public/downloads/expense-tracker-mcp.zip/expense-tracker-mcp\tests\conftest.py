from pathlib import Path

import pytest

from expense_tracker_mcp.database import ExpenseDatabase


@pytest.fixture
def database(tmp_path: Path) -> ExpenseDatabase:
    db = ExpenseDatabase(tmp_path / "expenses.sqlite3")
    db.initialize()
    return db
