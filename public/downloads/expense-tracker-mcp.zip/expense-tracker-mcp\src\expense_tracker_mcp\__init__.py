"""Local personal expense tracker MCP server."""
