"""FastMCP entry point and six Expense Tracker tools."""

import os
from datetime import date
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from .database import ExpenseDatabase
from .models import Expense
from .money import MoneyError, format_inr, parse_amount_to_paise
from .validation import (
    ValidationError,
    validate_category,
    validate_date,
    validate_description,
    validate_month,
    validate_payment_method,
)


class ToolError(ValueError):
    """An expected user-facing error which FastMCP returns as a tool error."""


def default_database_path() -> Path:
    """Choose a project-local database unless explicitly overridden for testing."""
    configured = os.environ.get("EXPENSE_TRACKER_DB")
    return (
        Path(configured)
        if configured
        else Path(__file__).resolve().parents[2] / "data" / "expenses.sqlite3"
    )


def expense_result(expense: Expense) -> dict[str, object]:
    """Add a readable INR amount to an expense's stored fields."""
    result = expense.to_dict()
    result["amount"] = format_inr(expense.amount_paise)
    return result


def create_server(database: ExpenseDatabase | None = None) -> FastMCP:
    """Create a server, optionally with a test database injected by pytest."""
    db = database or ExpenseDatabase(default_database_path())
    db.initialize()
    mcp = FastMCP(
        "Personal Expense Tracker", instructions="Track local personal expenses using SQLite."
    )

    @mcp.tool()
    def add_expense(
        amount_rupees: str,
        category: str,
        description: str,
        expense_date: str | None = None,
        payment_method: str = "upi",
    ) -> dict[str, object]:
        """Add one expense. amount_rupees accepts values like '₹1,200.50'."""
        try:
            expense = db.add(
                parse_amount_to_paise(amount_rupees),
                validate_category(category),
                validate_description(description),
                validate_date(expense_date or date.today().isoformat()),
                validate_payment_method(payment_method),
            )
        except (MoneyError, ValidationError) as exc:
            raise ToolError(str(exc)) from exc
        return {"message": "Expense added successfully.", "expense": expense_result(expense)}

    @mcp.tool()
    def list_expenses(
        month: str | None = None, category: str = "all", limit: int = 50
    ) -> dict[str, object]:
        """List newest expenses first; optionally filter by calendar month and category."""
        try:
            if month is not None:
                month = validate_month(month)
            if category != "all":
                validate_category(category)
            if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 200:
                raise ValidationError("limit must be an integer between 1 and 200.")
        except ValidationError as exc:
            raise ToolError(str(exc)) from exc
        expenses = db.list(month=month, category=category, limit=limit)
        total = sum(item.amount_paise for item in expenses)
        return {
            "expenses": [expense_result(item) for item in expenses],
            "count": len(expenses),
            "total_paise": total,
            "total": format_inr(total),
        }

    @mcp.tool()
    def get_monthly_total(month: str) -> dict[str, object]:
        """Return the exact monthly total calculated by SQLite SUM."""
        try:
            month = validate_month(month)
        except ValidationError as exc:
            raise ToolError(str(exc)) from exc
        count, total = db.monthly_total(month)
        return {
            "month": month,
            "expense_count": count,
            "total_paise": total,
            "total": format_inr(total),
        }

    @mcp.tool()
    def category_breakdown(month: str) -> dict[str, object]:
        """Return per-category monthly totals calculated by SQLite GROUP BY."""
        try:
            month = validate_month(month)
        except ValidationError as exc:
            raise ToolError(str(exc)) from exc
        _, total = db.monthly_total(month)
        rows = db.breakdown(month)
        breakdown = [
            {
                "category": category,
                "expense_count": count,
                "total_paise": paise,
                "total": format_inr(paise),
                "percentage": round((paise / total * 100) if total else 0, 2),
            }
            for category, count, paise in rows
        ]
        return {
            "month": month,
            "total_paise": total,
            "total": format_inr(total),
            "categories": breakdown,
        }

    @mcp.tool()
    def update_expense(
        expense_id: int,
        amount_rupees: str | None = None,
        category: str | None = None,
        description: str | None = None,
        expense_date: str | None = None,
        payment_method: str | None = None,
    ) -> dict[str, object]:
        """Change one or more fields of an existing expense."""
        updates: dict[str, object] = {}
        try:
            if amount_rupees is not None:
                updates["amount_paise"] = parse_amount_to_paise(amount_rupees)
            if category is not None:
                updates["category"] = validate_category(category)
            if description is not None:
                updates["description"] = validate_description(description)
            if expense_date is not None:
                updates["expense_date"] = validate_date(expense_date)
            if payment_method is not None:
                updates["payment_method"] = validate_payment_method(payment_method)
        except (MoneyError, ValidationError) as exc:
            raise ToolError(str(exc)) from exc
        if not updates:
            raise ToolError("Provide at least one field to update.")
        expense = db.update(expense_id, updates)
        if expense is None:
            raise ToolError(f"Expense {expense_id} does not exist.")
        return {"message": "Expense updated successfully.", "expense": expense_result(expense)}

    @mcp.tool()
    def delete_expense(expense_id: int, confirm: bool = False) -> dict[str, object]:
        """Delete an expense only after explicit confirm=true confirmation."""
        if not confirm:
            raise ToolError(
                "Deletion needs explicit confirmation. Set confirm=true after the user confirms."
            )
        expense = db.delete(expense_id)
        if expense is None:
            raise ToolError(f"Expense {expense_id} does not exist.")
        return {"message": "Expense deleted successfully.", "expense": expense_result(expense)}

    @mcp.resource("expenses://current-month/summary")
    def current_month_summary() -> dict[str, Any]:
        """Read-only summary of the current calendar month."""
        month = date.today().strftime("%Y-%m")
        count, total = db.monthly_total(month)
        categories = [
            {
                "category": category,
                "expense_count": item_count,
                "total_paise": paise,
                "total": format_inr(paise),
                "percentage": round((paise / total * 100) if total else 0, 2),
            }
            for category, item_count, paise in db.breakdown(month)
        ]
        highest = db.highest(month)
        return {
            "month": month,
            "expense_count": count,
            "total_paise": total,
            "total": format_inr(total),
            "category_breakdown": categories,
            "highest_individual_expense": expense_result(highest) if highest else None,
        }

    @mcp.prompt()
    def analyze_monthly_spending(month: str) -> str:
        """Give an AI a reusable, read-only plan for monthly expense analysis."""
        validate_month(month)
        return (
            f"Analyze the user's spending for {month}. First call get_monthly_total with this "
            "month, then category_breakdown, then list_expenses. Identify the largest categories "
            "and unusually large individual expenses. Summarize without judging the user "
            "and suggest "
            "two or three realistic savings opportunities. Display every amount in Indian Rupees. "
            "Do not call update_expense or delete_expense; this is read-only analysis."
        )

    return mcp


def main() -> None:
    """Start the server over stdio; FastMCP owns protocol output."""
    create_server().run(transport="stdio")


if __name__ == "__main__":
    main()
