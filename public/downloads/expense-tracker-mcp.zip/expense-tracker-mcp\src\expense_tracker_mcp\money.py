"""Safe parsing and display of Indian Rupee amounts."""

from decimal import Decimal, InvalidOperation


class MoneyError(ValueError):
    """Raised when an amount is not a positive value with at most two decimals."""


def parse_amount_to_paise(amount: str) -> int:
    """Convert an INR amount string into paise without using floats."""
    if not isinstance(amount, str):
        raise MoneyError("Amount must be supplied as text, for example '350.00'.")
    cleaned = amount.strip().replace("₹", "").replace(",", "")
    if not cleaned:
        raise MoneyError("Amount cannot be empty.")
    try:
        value = Decimal(cleaned)
    except InvalidOperation as exc:
        raise MoneyError("Amount must be a valid number, for example '350.00'.") from exc
    if not value.is_finite() or value <= 0:
        raise MoneyError("Amount must be greater than zero.")
    if value.as_tuple().exponent < -2:
        raise MoneyError("Amount can have at most two decimal places.")
    paise = value * 100
    if paise != paise.to_integral_value():
        raise MoneyError("Amount can have at most two decimal places.")
    return int(paise)


def format_inr(amount_paise: int) -> str:
    """Format integer paise as an Indian Rupee string, such as ₹12,34,567.00."""
    sign = "-" if amount_paise < 0 else ""
    whole, fraction = divmod(abs(amount_paise), 100)
    digits = str(whole)
    if len(digits) > 3:
        tail = digits[-3:]
        head = digits[:-3]
        groups: list[str] = []
        while head:
            groups.append(head[-2:])
            head = head[:-2]
        digits = ",".join(reversed(groups)) + "," + tail
    return f"{sign}₹{digits}.{fraction:02d}"
