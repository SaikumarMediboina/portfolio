from expense_tracker_mcp.database import ExpenseDatabase
from expense_tracker_mcp.server import create_server


def test_mcp_registers_six_tools_resource_and_prompt(database: ExpenseDatabase) -> None:
    server = create_server(database)
    assert len(server._tool_manager._tools) == 6
    assert "expenses://current-month/summary" in server._resource_manager._resources
    assert "analyze_monthly_spending" in server._prompt_manager._prompts


def test_current_month_resource_is_read_only(database: ExpenseDatabase) -> None:
    server = create_server(database)
    resource = server._resource_manager._resources["expenses://current-month/summary"]
    before = database.list()
    assert resource.fn()["expense_count"] == 0
    assert database.list() == before
