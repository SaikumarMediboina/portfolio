# Expense Tracker MCP Server

A local, beginner-friendly MCP server for recording personal expenses in SQLite. It never connects to banks, payment services, or external financial systems.

## Architecture

```text
MCP client / AI application
        | stdio
FastMCP server (server.py)
        | validates inputs
SQLite repository (database.py) <---> data/expenses.sqlite3
        |
money.py: Decimal input -> integer paise -> INR display
```

For the AI terminal client, the complete request path is:

```text
Your terminal message -> OpenAI model -> selected MCP tool -> local MCP server
     -> SQLite -> MCP tool result -> OpenAI model -> terminal answer
```

The terminal application is the **host** in this design. It connects to the local stdio
server, gives the server's tool schemas to the model, and executes only the tools selected
by the model. The model never receives direct SQLite access.

## Install and run

Requires Python 3.11+ and [uv](https://docs.astral.sh/uv/).

```powershell
cd expense-tracker-mcp
uv sync --all-groups
uv run expense-tracker-mcp
```

The server uses stdio. Keep its terminal reserved for the MCP client; it intentionally emits no normal output. The database is created at `data/expenses.sqlite3` (or set `EXPENSE_TRACKER_DB` for a different local path).

Run checks:

```powershell
uv run ruff format .
uv run ruff check .
uv run pytest
```

Pytest keeps its temporary test databases in `.pytest-tmp`, so it does not need access to the Windows user Temp directory.

Run a terminal-only MCP demonstration (no Inspector, npm, or proxy required):

```powershell
uv run python terminal_demo.py
```

It starts the server using the same Python environment, calls real MCP tools, prints their JSON results, and removes its temporary demo database.

For an interactive terminal client that saves your real local expenses, run:

```powershell
uv run --no-sync python terminal_app.py
```

Then type `add 350 Lunch under food`, `total 2026-07`, or `help`. This client calls the MCP tools over stdio; it does not use npm, a proxy, or an external service.

## Run the real AI + MCP terminal flow

This is the version where you type a normal sentence, an OpenAI model chooses an MCP tool,
and the local MCP server executes it. It needs an OpenAI API key and internet access to the
OpenAI API; it does not need npm or the MCP Inspector.

In PowerShell, set the key only for the current terminal window (do not paste it into a
Python file or commit it):

```powershell
$env:OPENAI_API_KEY = "your_api_key_here"
uv run --no-sync python ai_terminal_app.py
```

Optional: choose another model available to your API account.

```powershell
$env:OPENAI_MODEL = "gpt-5"
```

Then try:

```text
you> Add ₹350 for lunch under food
you> Show my spending breakdown for 2026-07
you> Delete expense 1
you> Yes, delete expense 1
```

`ai_terminal_app.py` uses Python's built-in HTTPS support, so no extra Python package,
npm registry, Inspector, or company proxy configuration is changed by this project. API
usage is billed to the OpenAI API account associated with your key.

With Node.js available, inspect it using:

```powershell
npx @modelcontextprotocol/inspector uv run expense-tracker-mcp
```

## Tools

| Tool | Inputs | Example |
|---|---|---|
| `add_expense` | amount, category, description, optional date/method | `{"amount_rupees":"350","category":"food","description":"Lunch"}` |
| `list_expenses` | optional month/category/limit | `{"month":"2026-07","category":"all"}` |
| `get_monthly_total` | month | `{"month":"2026-07"}` |
| `category_breakdown` | month | `{"month":"2026-07"}` |
| `update_expense` | id plus one or more fields | `{"expense_id":3,"amount_rupees":"850","category":"groceries"}` |
| `delete_expense` | id, explicit confirmation | `{"expense_id":3,"confirm":true}` |

Categories are `food`, `groceries`, `travel`, `bills`, `shopping`, `entertainment`, `health`, `education`, and `other`. Payment methods are `cash`, `upi`, `card`, `bank_transfer`, and `other`.

## Resource and prompt

`expenses://current-month/summary` is a read-only JSON snapshot of this month's total, category breakdown, and highest expense.

`analyze_monthly_spending` is a reusable prompt that tells an AI to call the three reporting tools and give non-judgmental, read-only INR advice.

## Troubleshooting and privacy

If `uv` is unavailable, install it, reopen the terminal, then run `uv sync --all-groups`. If an MCP client fails to connect, confirm its command is `uv run expense-tracker-mcp` and that it launches from this folder. Do not print debug logs to stdout.

Your entries stay in a local SQLite file. The direct terminal client never sends them outside
your computer. The AI terminal client sends your typed request and MCP tool results to the
OpenAI API so the model can answer; keep that in mind before using it with sensitive data.
This project does not contact any financial institution, encrypt the SQLite file, or
authenticate users; protect your computer account, database file, and API key accordingly.
