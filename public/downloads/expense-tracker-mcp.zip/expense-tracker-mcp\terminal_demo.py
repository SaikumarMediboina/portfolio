"""Run a safe, terminal-only demonstration through the real MCP protocol.

This script is a local MCP client. Unlike the server command, it is designed
for a person to run in PowerShell and read its output.
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

PROJECT_ROOT = Path(__file__).resolve().parent

# Windows consoles can otherwise default to a code page that cannot print ₹.
sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def display_result(title: str, result: Any) -> None:
    """Print a readable MCP tool response without assuming a result shape."""
    print(f"\n--- {title} ---")
    for content in result.content:
        if hasattr(content, "text"):
            try:
                print(json.dumps(json.loads(content.text), ensure_ascii=False, indent=2))
            except json.JSONDecodeError:
                print(content.text)
    if result.isError:
        print("Tool returned an expected error.")


async def call(session: ClientSession, name: str, arguments: dict[str, object]) -> Any:
    """Call one real MCP tool and show the result."""
    result = await session.call_tool(name, arguments=arguments)
    display_result(name, result)
    return result


async def run_demo() -> None:
    """Start the server locally, exercise tools, then discard the demo database."""
    with TemporaryDirectory(prefix="expense-tracker-demo-") as temporary_directory:
        environment = os.environ.copy()
        environment["EXPENSE_TRACKER_DB"] = str(Path(temporary_directory) / "demo.sqlite3")
        parameters = StdioServerParameters(
            command=sys.executable,
            args=["-m", "expense_tracker_mcp.server"],
            env=environment,
            cwd=PROJECT_ROOT,
        )
        async with stdio_client(parameters) as (reader, writer):
            async with ClientSession(reader, writer) as session:
                await session.initialize()
                print("Expense Tracker terminal demo (temporary data only)")
                await call(
                    session,
                    "add_expense",
                    {
                        "amount_rupees": "350",
                        "category": "food",
                        "description": "Lunch",
                        "expense_date": "2026-07-25",
                        "payment_method": "upi",
                    },
                )
                await call(
                    session,
                    "add_expense",
                    {
                        "amount_rupees": "1200",
                        "category": "bills",
                        "description": "Electricity bill",
                        "expense_date": "2026-07-25",
                        "payment_method": "bank_transfer",
                    },
                )
                await call(session, "get_monthly_total", {"month": "2026-07"})
                await call(session, "category_breakdown", {"month": "2026-07"})
                await call(
                    session,
                    "delete_expense",
                    {"expense_id": 1, "confirm": False},
                )
                await call(
                    session,
                    "delete_expense",
                    {"expense_id": 1, "confirm": True},
                )
    print("\nDemo complete. Its temporary SQLite database was removed.")


if __name__ == "__main__":
    asyncio.run(run_demo())
