import pytest

from expense_tracker_mcp.money import MoneyError, format_inr, parse_amount_to_paise


@pytest.mark.parametrize(
    ("amount", "paise"), [("350", 35000), ("350.75", 35075), ("₹1,200.50", 120050)]
)
def test_parse_amount_to_paise(amount: str, paise: int) -> None:
    assert parse_amount_to_paise(amount) == paise


@pytest.mark.parametrize("amount", ["0", "-1", "hello", "1.001"])
def test_invalid_money_is_rejected(amount: str) -> None:
    with pytest.raises(MoneyError):
        parse_amount_to_paise(amount)


def test_indian_formatting() -> None:
    assert format_inr(35000) == "₹350.00"
    assert format_inr(123456700) == "₹12,34,567.00"
